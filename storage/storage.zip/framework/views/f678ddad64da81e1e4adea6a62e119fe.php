 

<?php $__env->startSection('title', 'إدارة طلبات العضوية'); ?>
<?php $__env->startSection('page-title', 'إدارة طلبات العضوية'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .add-section {
        background: #212529;
        color: white;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 30px;
    }

    .form-control,
    .form-select {
        border-radius: 8px;
        border: 1px solid #ddd;
        padding: 10px 15px;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
    }

    .table-responsive {
        border-radius: 10px;
        overflow: hidden;
        margin-bottom: 30px;
        /* إضافة مسافة بين الجداول */
    }

    .action-buttons .btn {
        padding: 5px 10px;
        font-size: 12px;
        margin: 0 2px;
    }

    .about-img {
        width: 50px;
        height: auto;
        border-radius: 5px;
        box-shadow: 0 0 3px rgba(0, 0, 0, 0.2);
    }

</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>



<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-dark">كل الطلبات</h6>
    </div>
    <div class="card-body">
        <div class="add-section mb-4">
            <form method="GET" action="<?php echo e(route('admin.manageMembership.index')); ?>" class="row g-3 align-items-end">
                <!-- حقل البحث -->
                <div class="col-md-4">
                    <label for="search" class="form-label">البحث بالاسم أو رقم الهاتف</label>
                    <input type="text" name="search" id="search" class="form-control" value="<?php echo e(request('search')); ?>" placeholder="ابحث هنا...">
                </div>

                <!-- حقل الفرز -->
                <div class="col-md-3">
                    <label for="sort_by" class="form-label">فرز حسب</label>
                    <select name="sort_by" id="sort_by" class="form-select">
                        <option value="">اختر...</option>
                        <option value="date" <?php echo e(request('sort_by') == 'date' ? 'selected' : ''); ?>>تاريخ الطلب</option>
                        <option value="emirate" <?php echo e(request('sort_by') == 'emirate' ? 'selected' : ''); ?>>الإمارة</option>
                        <option value="gender" <?php echo e(request('sort_by') == 'gender' ? 'selected' : ''); ?>>الجنس</option>
                        <option value="nationality" <?php echo e(request('sort_by') == 'nationality' ? 'selected' : ''); ?>>الجنسية</option>
                    </select>
                </div>

                <!-- اتجاه الفرز -->
                <div class="col-md-3">
                    <label for="sort_direction" class="form-label">اتجاه الفرز</label>
                    <select name="sort_direction" id="sort_direction" class="form-select">
                        <option value="desc" <?php echo e(request('sort_direction') == 'desc' ? 'selected' : ''); ?>>تنازلي</option>
                        <option value="asc" <?php echo e(request('sort_direction') == 'asc' ? 'selected' : ''); ?>>تصاعدي</option>
                    </select>
                </div>

                <!-- زر الإرسال -->
                <div class="col-md-2">
                    <button type="submit" class="btn btn-light w-100">تطبيق</button>
                </div>
            </form>
        </div>

<div class="table-responsive">
    <table class="table table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>تاريخ الطلب</th>
                <th>رقم العضوية</th>
                <th>الجنسية</th>
                <th>الإمارة</th>
                <th>رقم الهاتف</th>
                <th>الجنس</th>
                <th>الصورة الرئيسية</th>
                <th>الحالة</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php if($membership->isNotEmpty()): ?>
            <?php $__currentLoopData = $membership; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($member->id); ?></td>
                <td><?php echo e(optional($member->created_at)->format('d/m/Y') ?? 'N/A'); ?></td>
                <td><?php echo e($member->full_name ?? 'لا يوجد اسم'); ?></td>
                <td><?php echo e($member->nationality ?? 'لا توجد جنسية'); ?></td>
                <td><?php echo e($member->emirate ?? 'لا توجد إمارة'); ?></td>
                <td><?php echo e($member->mobile_phone ?? 'غير محدد'); ?></td>
                <td><?php echo e($member->gender == 'male' ? 'ذكر' : 'أنثى'); ?></td>
                <td>
                    <?php if($member->personal_photo_path): ?>
                    <img style="height: 50px;" src="<?php echo e(asset('storage/' . $member->personal_photo_path)); ?>" alt="<?php echo e($member->full_name); ?>" class="about-img">
                    <?php else: ?>
                    <img src="/assets/images/default_user.jpg" alt="<?php echo e($member->full_name); ?>" class="about-img">
                    <?php endif; ?>
                </td>
                <td>
                    <span style="color: white; border-radius: 5px; padding: 0px 3px; <?php echo e($member->status == '0' ? 'background: red' : ($member->status == '1' ? 'background: purple' : ($member->status == '2' ? 'background: blue' : ($member->status == '3' ? 'background: green' : 'background: orange')))); ?>">
                        <?php switch($member->status):
                        case ('0'): ?> بإنتظار الدفع <?php break; ?>
                        <?php case ('1'): ?> بإنتظار التفعيل <?php break; ?>
                        <?php case ('2'): ?> بإنتظار الموافقة <?php break; ?>
                        <?php case ('3'): ?> فعال <?php break; ?>
                        <?php case ('4'): ?> منتهي <?php break; ?>
                        <?php default: ?> حالة غير معروفة <?php endswitch; ?>
                    </span>
                </td>
                <td>
                    <div class="action-buttons">
                        <a href="<?php echo e(route('admin.member.show', $member->id)); ?>" class="btn btn-info btn-sm" title="عرض">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('admin.manageMembership.edit', $member->id)); ?>" class="btn btn-warning btn-sm" title="تعديل">
                            <i class="fas fa-edit"></i>
                        </a>
                        <button class="btn btn-danger btn-sm" title="حذف" onclick="confirmDeleteModal('members', <?php echo e($member->id); ?>)">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td colspan="10" class="text-center py-4">
                    <i class="fas fa-info-circle text-muted" style="font-size: 3rem;"></i>
                    <p class="text-muted mt-2">لا يوجد أعضاء بعد. يرجى <a href="<?php echo e(route('admin.member.create')); ?>">الإضافة الآن</a></p>
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- إضافة التصفح (Pagination) -->
    <div class="d-flex justify-content-center">
        <?php echo e($membership->appends(request()->query())->links('pagination::bootstrap-5')); ?>

    </div>
</div>
</div>

</div>




<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">تأكيد الحذف</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="deleteModalBody">
                هل أنت متأكد من حذف هذا العنصر؟
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                <form id="deleteForm" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">حذف</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // الدوال الخاصة بمعاينة الصور (إذا كنت تستخدم هذا الـ view للإضافة/التعديل، ولكن غالباً هذا الـ view للعرض فقط)
    // تم حذف هذا الجزء من السكربت لتجنب الازدواجية حيث أن هذا الـ view هو لعرض البيانات فقط.
    // إذا كنت تحتاج هذه الوظائف، يجب أن تكون في view الإضافة/التعديل.

    function confirmDeleteModal(type, id) {
        const deleteForm = document.getElementById('deleteForm');
        const deleteModalBody = document.getElementById('deleteModalBody');

        deleteForm.action = `/admin/member/${id}`;
        deleteModalBody.textContent = 'هل أنت متأكد من حذف محتوى صفحة "معلومات العضو ؟';

        const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
        deleteModal.show();
    }

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Retirees\resources\views/admin/manageMembership/index.blade.php ENDPATH**/ ?>