<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/fav.png')); ?>" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width; initial-scale=1;" />
    <title>بيانات العضوية</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/other-devices.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleU.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/amazingslider-1.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/amazingslider-2.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/custom.css')); ?>">
</head>
<body>
    <?php if (isset($component)) { $__componentOriginal1599bb83f8a5081aa583bd9ac337e33d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1599bb83f8a5081aa583bd9ac337e33d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1599bb83f8a5081aa583bd9ac337e33d)): ?>
<?php $attributes = $__attributesOriginal1599bb83f8a5081aa583bd9ac337e33d; ?>
<?php unset($__attributesOriginal1599bb83f8a5081aa583bd9ac337e33d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1599bb83f8a5081aa583bd9ac337e33d)): ?>
<?php $component = $__componentOriginal1599bb83f8a5081aa583bd9ac337e33d; ?>
<?php unset($__componentOriginal1599bb83f8a5081aa583bd9ac337e33d); ?>
<?php endif; ?>

    <div class="membership">
        <div>
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('members.membership-show')); ?>" id="reg" class="btn-qhr btn-primary-t6n">
                التسجيل
            </a>
            <?php else: ?>
            <a href="#" id="reg" class="btn-qhr btn-primary-t6n">التسجيل</a>
            <?php endif; ?>
        </div>
        <div>
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <?php if($section->section == 'membership_description'): ?>
                <div class="container-membership">
                    <div>
                        <h5 class="member-title"><?php echo e($section->title_ar ?? 'وصف العضوية'); ?></h5>
                        <p><?php echo e($section->description_ar ?? 'لا يوجد وصف'); ?></p>
                    </div>
                    <div class="img-container">
                        <img src="<?php echo e(asset('assets/images/new-logo.png')); ?>" alt="شعار العضوية">
                    </div>
                </div>
                <?php elseif($section->section == 'value'): ?>
                <h5 class="member-title">
                    <?php echo e($section->title_ar ?? 'القيمة'); ?>

                </h5>
                <p><?php echo e($section->description_ar ?? 'لا يوجد وصف'); ?> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" style="margin-right: 3px;" viewBox="0 0 24 24" fill="none">
                        <path d="M8 7V17H12C14.8 17 17 14.8 17 12C17 9.2 14.8 7 12 7H8Z" stroke="#000" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M6.5 11H18.5" stroke="#000" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M6.5 13H12.5H18.5" stroke="#000" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg></p>
                <?php else: ?>
                <h5 class="member-title"><?php echo e($section->title_ar ?? ($sectionTypes[$section->section] ?? $section->section)); ?></h5>
                <p><?php echo e($section->description_ar ?? 'لا يوجد وصف'); ?></p>
                <?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($sections->isEmpty()): ?>
            <div class="text-center py-4">
                <i class="fas fa-info-circle text-muted" style="font-size: 3rem;"></i>
                <p class="text-muted mt-2">لا توجد بيانات للأقسام حاليًا.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal3fe645749ed3f4be8530f5256d446f0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fe645749ed3f4be8530f5256d446f0f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer-section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fe645749ed3f4be8530f5256d446f0f)): ?>
<?php $attributes = $__attributesOriginal3fe645749ed3f4be8530f5256d446f0f; ?>
<?php unset($__attributesOriginal3fe645749ed3f4be8530f5256d446f0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fe645749ed3f4be8530f5256d446f0f)): ?>
<?php $component = $__componentOriginal3fe645749ed3f4be8530f5256d446f0f; ?>
<?php unset($__componentOriginal3fe645749ed3f4be8530f5256d446f0f); ?>
<?php endif; ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.js"></script>
    <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/modernizr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/amazingcarousel.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/initcarousel-1.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/amazingslider.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/initslider-2.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scriptU.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const regLink = document.getElementById('reg');
            regLink.addEventListener('click', function(e) {
                <?php if(auth()->guard()->guest()): ?>
                e.preventDefault();
                Swal.fire({
                    title: 'غير مسجل الدخول'
                    , text: 'يرجى تسجيل الدخول للوصول إلى هذه الصفحة'
                    , icon: 'warning'
                    , confirmButtonText: 'تسجيل الدخول'
                    , showCancelButton: true
                    , cancelButtonText: 'إلغاء'
                    , confirmButtonColor: '#b28b46'
                    , cancelButtonColor: '#dc3545'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = "<?php echo e(route('members.login')); ?>";
                    }
                });
                <?php endif; ?>
            });
        });

    </script>
</body>
</html>
<?php /**PATH F:\Retirees\resources\views/members/sidebar/membership.blade.php ENDPATH**/ ?>