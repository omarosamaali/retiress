<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['services']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['services']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div id="events-section" style="display: flex;">
    <div class="services">
        <div class="title" style="display: flex; justify-content: space-between; max-width: 1200px; width: 100%; margin: auto; ">
            <h3 style="flex: 1; font-size: 36px; color: #000;">خدماتنا</h3>
            <a href="<?php echo e(route('services.all-services')); ?>" class="main-btn" style="margin-left: 20px; margin-top: 50px; height: min-content; background-color: black;">المزيد
            </a>
        </div>
        <div>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serivce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="service pe">
                <img class="service-img" src="<?php echo e(asset('assets/images/pe.png')); ?>" alt="">
                <h4 class="servicetitle"><?php echo e($serivce->name_ar); ?></h4>
                <p class="servicedesc"><?php echo e($serivce->description_ar); ?></p>
                <a href="<?php echo e(route('services.show', $serivce)); ?>" class="servicelink"><img src="<?php echo e(asset('assets/images/link.jpg')); ?>" /></a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH F:\Retirees\resources\views/components/events-section.blade.php ENDPATH**/ ?>