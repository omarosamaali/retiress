<?php $__env->startSection('title', 'إدارة بيانات العضوية'); ?>
<?php $__env->startSection('page-title', 'إدارة بيانات العضوية'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .add-section {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 30px;
    }

    .form-control,
    .form-select {
        border-radius: 8px;
        border: 1px solid #ddd;
        padding: 10px 15px;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
    }

    .table-responsive {
        border-radius: 10px;
        overflow: hidden;
        margin-bottom: 30px;
    }

    .action-buttons .btn {
        padding: 5px 10px;
        font-size: 12px;
        margin: 0 2px;
    }

</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-dark">إدارة بيانات العضوية</h6>
        <a href="<?php echo e(route('admin.membership.create')); ?>" class="btn btn-success btn-sm">إضافة قسم جديد</a>
    </div>
    <div class="card-body">
        <?php if($sections->isNotEmpty()): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>القسم</th>
                        <th>تاريخ الإضافة</th>
                        <th>العنوان (عربي)</th>
                        <th>الوصف (عربي)</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($section->id); ?></td>
                        <td>
                            <?php
                            $sectionTypes = [
                            'membership_description' => 'وصف العضوية',
                            'privileges' => 'امتيازات العضوية',
                            'target_audience' => 'الجمهور المستهدف',
                            'required_documents' => 'الوثائق المطلوبة',
                            'subscription_months' => 'عدد أشهر الاشتراك',
                            'value' => 'القيمة',

                            ];
                            ?>
                            <?php echo e($sectionTypes[$section->section] ?? $section->section); ?>

                        </td>

                        <td><?php echo e(optional($section->created_at)->format('d/m/Y') ?? 'N/A'); ?></td>
                        <td><?php echo e($section->title_ar ?? 'لا يوجد عنوان'); ?></td>
                        <td><?php echo e(Str::limit($section->description_ar, 50)); ?></td>

                        <td>
                            <div class="action-buttons">
                                <a href="<?php echo e(route('admin.membership.show', $section)); ?>" class="btn btn-info btn-sm" title="عرض">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.membership.edit', $section)); ?>" class="btn btn-warning btn-sm" title="تعديل">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button class="btn btn-danger btn-sm" title="حذف" onclick="confirmDelete('memberships', <?php echo e($section->id); ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-info-circle text-muted" style="font-size: 3rem;"></i>
            <p class="text-muted mt-2">لا توجد بيانات للأقسام. يرجى <a href="<?php echo e(route('admin.membership.create')); ?>">إضافة الآن</a></p>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmDelete(type, id) {
        Swal.fire({
            title: 'تأكيد الحذف'
            , text: 'هل أنت متأكد من حذف هذا القسم؟'
            , icon: 'warning'
            , showCancelButton: true
            , confirmButtonText: 'حذف'
            , cancelButtonText: 'إلغاء'
            , confirmButtonColor: '#dc3545'
            , cancelButtonColor: '#6c757d'
        }).then((result) => {
            if (result.isConfirmed) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = `/admin/${type}/${id}`;
                form.style.display = 'none';

                const methodInput = document.createElement('input');
                methodInput.name = '_method';
                methodInput.value = 'DELETE';
                form.appendChild(methodInput);

                const csrfInput = document.createElement('input');
                csrfInput.name = '_token';
                csrfInput.value = '<?php echo e(csrf_token()); ?>';
                form.appendChild(csrfInput);

                document.body.appendChild(form);
                form.submit();
            }
        });
    }

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Retirees\resources\views/admin/membership/index.blade.php ENDPATH**/ ?>