<?php $__env->startSection('title', 'إضافة مجلس'); ?>
<?php $__env->startSection('page-title', 'إضافة مجلس'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .add-section {
        background: white;
        color: black;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 30px;
    }

    .form-control,
    .form-select {
        border-radius: 8px;
        border: 1px solid #ddd;
        padding: 10px 15px;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: #0e6939;
        box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
    }

    .about-preview {
        max-width: 200px;
        height: auto;
        border-radius: 8px;
        box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
    }

    .translated-name-field {
        background-color: rgba(255, 255, 255, 0.1);
        border-color: rgba(255, 255, 255, 0.3);
        color: black;
    }

    .translated-name-field:focus {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: white;
    }

    .btn-section {
        margin-top: 20px;
    }

    .back-btn {
        background: #6c757d;
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        text-decoration: none;
        margin-right: 10px;
        display: inline-block;
    }

    .back-btn:hover {
        background: #545b62;
        color: white;
    }

    .update-btn {
        background: #28a745;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .update-btn:hover {
        background: #218838;
    }

</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="add-section">
    <h5 class="mb-4">
        <i class="fas fa-info-circle ms-2 text-primary" style="margin-left: 10px; font-size: 1rem;"></i>
        إضافة مجلس
    </h5>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.council.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="name_ar" class="form-label font-bold">العنوان (بالعربية)</label>
                    <input type="text" class="form-control" id="name_ar" name="name_ar" value="<?php echo e(old('name_ar')); ?>" required>
                    <?php $__errorArgs = ['name_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-black"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="col-md-6">
                <div class="mb-3">
                    <label for="description_ar" class="form-label font-bold">الوصف (بالعربية)</label>
                    <textarea class="form-control" id="description_ar" name="description_ar" rows="4" required><?php echo e(old('description_ar')); ?></textarea>
                    <?php $__errorArgs = ['description_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-black"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="image" class="form-label font-bold">الصورة</label>
                    <input type="file" class="form-control" id="image_input" name="image" value="<?php echo e(old('image')); ?>">
                    <img id="image_preview" src="#" alt="معاينة الصورة الجديدة" class="about-preview mt-2" style="display: none;"> <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                    <div class="text-black"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <img id="image_preview" src="#" alt="معاينة الصورة الجديدة" class="about-preview mt-2" style="display: none;">
                </div>
            </div>

            <div class="col-md-6">
                <div class="mb-3">
                    <label for="status" class="form-label font-bold">الحالة</label>
                    <select class="form-select" name="status" id="status" required>
                        <option value="1" <?php echo e(old('status') == '1' ? 'selected' : ''); ?>>فعال</option>
                        <option value="0" <?php echo e(old('status') == '0' ? 'selected' : ''); ?>>غير فعال</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-black"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <div class="btn-section text-center">
            <a href="<?php echo e(route('admin.council.index')); ?>" class="back-btn">
                <i class="fas fa-arrow-right ms-1"></i>
                العودة للقائمة
            </a>

            <button type="submit" class="update-btn">
                <i class="fas fa-save ms-1"></i>
                حفظ التعديلات
            </button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const mainImageInput = document.getElementById('image_input');
        const mainImagePreview = document.getElementById('image_preview');
        const currentMainImagePreview = document.getElementById('current_image_preview');
        const removeMainImageCheckbox = document.getElementById('remove_image');

        const subImageInput = document.getElementById('sub_image_input');
        const subImagePreview = document.getElementById('sub_image_preview');
        const currentSubImagePreview = document.getElementById('current_sub_image_preview');
        const removeSubImageCheckbox = document.getElementById('remove_sub_image');

        if (mainImageInput) {
            mainImageInput.addEventListener('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        mainImagePreview.src = e.target.result;
                        mainImagePreview.style.display = 'block';
                        if (currentMainImagePreview) {
                            currentMainImagePreview.style.display = 'none';
                        }
                        if (removeMainImageCheckbox) {
                            removeMainImageCheckbox.checked = false;
                        }
                    };
                    reader.readAsDataURL(file);
                } else {
                    mainImagePreview.src = '#';
                    mainImagePreview.style.display = 'none';
                    if (currentMainImagePreview && !removeMainImageCheckbox.checked) {
                        currentMainImagePreview.style.display = 'block';
                    }
                }
            });
        }

        if (removeMainImageCheckbox) {
            removeMainImageCheckbox.addEventListener('change', function() {
                if (this.checked) {
                    if (currentMainImagePreview) {
                        currentMainImagePreview.style.display = 'none';
                    }
                    if (mainImagePreview) {
                        mainImagePreview.src = '#';
                        mainImagePreview.style.display = 'none';
                    }
                    if (mainImageInput) {
                        mainImageInput.value = '';
                    }
                } else {
                    if (currentMainImagePreview && currentMainImagePreview.src &&
                        currentMainImagePreview.src !== window.location.href) {
                        currentMainImagePreview.style.display = 'block';
                    }
                }
            });
        }

        if (subImageInput) {
            subImageInput.addEventListener('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        subImagePreview.src = e.target.result;
                        subImagePreview.style.display = 'block';
                        if (currentSubImagePreview) {
                            currentSubImagePreview.style.display = 'none';
                        }
                        if (removeSubImageCheckbox) {
                            removeSubImageCheckbox.checked = false;
                        }
                    };
                    reader.readAsDataURL(file);
                } else {
                    subImagePreview.src = '#';
                    subImagePreview.style.display = 'none';
                    if (currentSubImagePreview && !removeSubImageCheckbox.checked) {
                        currentSubImagePreview.style.display = 'block';
                    }
                }
            });
        }

        if (removeSubImageCheckbox) {
            removeSubImageCheckbox.addEventListener('change', function() {
                if (this.checked) {
                    if (currentSubImagePreview) {
                        currentSubImagePreview.style.display = 'none';
                    }
                    if (subImagePreview) {
                        subImagePreview.src = '#';
                        subImagePreview.style.display = 'none';
                    }
                    if (subImageInput) {
                        subImageInput.value = '';
                    }
                } else {
                    if (currentSubImagePreview && currentSubImagePreview.src &&
                        currentSubImagePreview.src !== window.location.href) {
                        currentSubImagePreview.style.display = 'block';
                    }
                }
            });
        }
    });

</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Retirees\resources\views/admin/councils/create.blade.php ENDPATH**/ ?>