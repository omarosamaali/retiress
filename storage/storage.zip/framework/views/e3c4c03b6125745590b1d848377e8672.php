<?php $__env->startSection('title', 'إدارة المستخدمين'); ?>
<?php $__env->startSection('page-title', 'إدارة المستخدمين'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .add-user-section {
            background: #fafafa;
            color: rgb(0, 0, 0);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }

        .form-control,
        .form-select {
            border-radius: 8px;
            border: 1px solid #ddd;
            padding: 10px 15px;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }

        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
        }

        .action-buttons .btn {
            padding: 5px 10px;
            font-size: 12px;
            margin: 0 2px;
        }

        .filter-buttons .btn {
            margin-right: 10px;
            min-width: 120px;
        }

        .chef-fields {
            display: none;
        }

        .official-image-preview {
            max-width: 200px;
            border-radius: 8px;
            margin-top: 10px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="add-user-section">
        <h5 class="mb-4">
            <i class="fas fa-user-plus ms-2"></i>
            إضافة مستخدم جديد
        </h5>

        <form action="<?php echo e(route('admin.users.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-3">
                    <div class="mb-3">
                        <label class="form-label">الاسم</label>
                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" >
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="mb-3">
                        <label class="form-label">البريد الإلكتروني</label>
                        <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" >
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-2">
                    <div class="mb-3">
                        <label class="form-label">كلمة السر</label>
                        <input type="password" class="form-control" name="password" >
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-2">
                    <div class="mb-3">
                        <label class="form-label">الصلاحية</label>
                        <select class="form-select" name="role" id="role" >
                            <option value="">اختر الصلاحية</option>
                            <option value="مدير" <?php echo e(old('role') == 'مدير' ? 'selected' : ''); ?>>مدير</option>
                            <option value="موظف استقبال" <?php echo e(old('role') == 'موظف استقبال' ? 'selected' : ''); ?>>موظف استقبال</option>
                            <option value="أمين سر" <?php echo e(old('role') == 'أمين سر' ? 'selected' : ''); ?>>أمين سر</option>
                            <option value="عضو" <?php echo e(old('role') == 'عضو' ? 'selected' : ''); ?>>عضو</option>
                            <option value="مدخل بيانات" <?php echo e(old('role') == 'مدخل بيانات' ? 'selected' : ''); ?>>مدخل بيانات</option>
                        </select>
                        <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-2">
                    <div class="mb-3">
                        <label for="status" class="form-label">الحالة</label>
                        <select class="form-select" name="status" id="status" >
                            <option value="فعال" <?php echo e(old('status') == 'فعال' ? 'selected' : ''); ?>>فعال</option>
                            <option value="غير فعال" <?php echo e(old('status') == 'غير فعال' ? 'selected' : ''); ?>>غير فعال</option>
                            <option value="بانتظار التفعيل" <?php echo e(old('status') == 'بانتظار التفعيل' ? 'selected' : ''); ?>>
                                بانتظار التفعيل</option>
                            <option value="بإنتظار إستكمال البيانات"
                                <?php echo e(old('status') == 'بإنتظار إستكمال البيانات' ? 'selected' : ''); ?>>
                                بانتظار التفعيل</option>
                        </select>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-light">
                <i class="fas fa-plus ms-1"></i>
                إضافة المستخدم
            </button>
        </form>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="mb-4 filter-buttons d-flex justify-content-center">
        <a href="<?php echo e(route('admin.users.index')); ?>"
            class="btn <?php echo e(request()->get('role') == '' ? 'btn-primary' : 'btn-outline-primary'); ?>">
            عرض الجميع
        </a>
        <a href="<?php echo e(route('admin.users.index', ['role' => 'مدير'])); ?>"
            class="btn <?php echo e(request()->get('role') == 'مدير' ? 'btn-primary' : 'btn-outline-primary'); ?>">
            المدراء
        </a>
        <a href="<?php echo e(route('admin.users.index', ['role' => 'موظف استقبال'])); ?>"
            class="btn <?php echo e(request()->get('role') == 'موظف استقبال' ? 'btn-primary' : 'btn-outline-primary'); ?>">
            موظف الإستقبال
        </a>
        <a href="<?php echo e(route('admin.users.index', ['role' => 'مدخل بيانات'])); ?>"
            class="btn <?php echo e(request()->get('role') == 'مدخل بيانات' ? 'btn-primary' : 'btn-outline-primary'); ?>">
            مدخل البيانات
        </a>
        <a href="<?php echo e(route('admin.users.index', ['role' => 'عضو'])); ?>"
            class="btn <?php echo e(request()->get('role') == 'عضو' ? 'btn-primary' : 'btn-outline-primary'); ?>">
            عضو
        </a>
        <a href="<?php echo e(route('admin.users.index', ['role' => 'أمين سر'])); ?>"
            class="btn <?php echo e(request()->get('role') == 'أمين سر' ? 'btn-primary' : 'btn-outline-primary'); ?>">
            أمين سر
        </a>
    </div>

    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>تاريخ الإضافة</th>
                    <th>الاسم</th>
                    <th>البريد الإلكتروني</th>
                    <th>الصلاحية</th>
                    <th>الحالة</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($user->created_at->format('d/m/Y')); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <span class="badge <?php echo e($user->getRoleBadgeClass()); ?>">
                                <?php echo e($user->role); ?>

                            </span>
                        </td>
                        <td>
                            <?php
                                $statusDisplay = '';
                                $badgeClass = '';

                                // المنطق الجديد: ابدأ بالحالة المخزنة في جدول المستخدم
                                // ثم قم بتعديلها للطهاة بناءً على اكتمال البيانات

                                // الحالة الافتراضية بناءً على $user->status
                                switch ($user->status) {
                                    case 'فعال':
                                        $statusDisplay = 'فعال';
                                        $badgeClass = 'success';
                                        break;
                                    case 'غير فعال':
                                        $statusDisplay = 'غير فعال';
                                        $badgeClass = 'secondary'; // أو danger حسب رغبتك
                                        break;
                                    case 'بانتظار التفعيل':
                                        $statusDisplay = 'بانتظار التفعيل';
                                        $badgeClass = 'warning';
                                        break;
                                    default:
                                        $statusDisplay = $user->status; // أي حالة أخرى
                                        $badgeClass = 'secondary';
                                        break;
                                }

                            ?>

                            <span class="badge bg-<?php echo e($badgeClass); ?>">
                                <?php echo e($statusDisplay); ?>

                            </span>



                        </td>
                        <td>
                            <div class="action-buttons">
                                <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" class="btn btn-info btn-sm"
                                    title="عرض">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-warning btn-sm"
                                    title="تعديل">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button class="btn btn-danger btn-sm" title="حذف"
                                    onclick="confirmDelete(<?php echo e($user->id); ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4">
                            <i class="fas fa-users text-muted" style="font-size: 3rem;"></i>
                            <p class="text-muted mt-2">لا توجد بيانات مستخدمين</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if(isset($users) && $users->hasPages()): ?>
        <div class="flex justify-center mt-4">
            <?php echo e($users->links('vendor.pagination.tailwind')); ?>

        </div>
    <?php endif; ?>

    <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تأكيد الحذف</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    هل أنت متأكد من حذف هذا المستخدم؟
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <form id="deleteForm" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">حذف</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const roleSelect = document.getElementById('role');
            const chefFields = document.getElementById('chef-fields');
            const contractTypeSelect = document.getElementById('contract_type');
            const subscriptionFields = document.getElementById('subscription-fields');

            // دالة لإظهار/إخفاء حقول الطاه وحقول الاشتراك
            function toggleFields() {
                const isChef = roleSelect.value === 'طاه';
                chefFields.style.display = isChef ? 'block' : 'none';
                subscriptionFields.style.display = isChef && contractTypeSelect.value === 'annual_subscription' ?
                    'block' : 'none';
            }

            // دالة لتأكيد الحذف باستخدام Bootstrap Modal
            window.confirmDelete = function(userId) {
                const deleteForm = document.getElementById('deleteForm');
                deleteForm.action = `/admin/users/${userId}`;
                const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
                deleteModal.show();
            };

            // إعداد الحالة الأولية عند تحميل الصفحة
            toggleFields();

            // مستمع لتغيير الدور
            roleSelect.addEventListener('change', toggleFields);

            // مستمع لتغيير نوع التعاقد
            contractTypeSelect.addEventListener('change', toggleFields);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Retirees\resources\views/admin/users/index.blade.php ENDPATH**/ ?>