<!DOCTYPE html>
<html>

<head>
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/fav.png')); ?>" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width; initial-scale=1;" />
    <title>أعضاء مجلس الإدارة</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/other-devices.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleU.css')); ?>" />
    <script src="<?php echo e(asset('assets/js/modernizr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/amazingcarousel.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/amazingslider-1.css')); ?>">
    <script src="<?php echo e(asset('assets/js/initcarousel-1.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/amazingslider.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/amazingslider-2.css')); ?>">
    <script src="<?php echo e(asset('assets/js/initslider-2.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(path: 'assets/css/custom.css')); ?>">
    <style>
        .board-member-card {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            padding: 20px;
            margin-bottom: 30px;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .board-member-card img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 30px;
            margin-bottom: 15px;
            border: 3px solid #eee;
        }

        .board-member-card h2 {
            font-size: 1.5rem;
            margin-bottom: 5px;
            color: #333;
        }

        .board-member-card h3 {
            font-size: 1.1rem;
            color: #666;
        }

        .board-members-grid {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
        }

        .board-members-grid>div {
            flex: 0 0 calc(50% - 30px);
            max-width: calc(50% - 30px);
        }

        @media (max-width: 768px) {
            .board-members-grid>div {
                flex: 0 0 100%;
                max-width: 100%;
            }
        }

        .board-member-card {
            position: relative;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            gap: 25px;
            max-width: 500px;
            width: 100%;
            overflow: hidden;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        /* تحريك الخطوط */
        @keyframes moveLines {
            0% {
                transform: translateX(-60px) translateY(-60px);
            }

            100% {
                transform: translateX(0px) translateY(0px);
            }
        }

        .board-member-card img {
            width: 150px;
            height: 150px;
            border-radius: 15px;
            object-fit: cover;
            border: 4px solid rgba(102, 126, 234, 0.3);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            position: relative;
            z-index: 2;
            transition: transform 0.3s ease;
        }

        .board-member-card:hover img {
            transform: scale(1.05);
        }

        .board-member-card>div {
            flex: 1;
            position: relative;
            z-index: 2;
        }

        .board-member-card h2 {
            margin: 0 0 10px 0;
            font-size: 24px;
            font-weight: bold;
            color: #2c3e50;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .board-member-card h3 {
            margin: 0;
            font-size: 18px;
            color: #0e6939;
            font-weight: 500;
            opacity: 0.8;
        }

        /* خطوط زينة جانبية */
        .decorative-lines {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 40px;
            height: 40px;
            z-index: 2;
        }

        .decorative-lines::before,
        .decorative-lines::after {
            content: '';
            position: absolute;
            background: linear-gradient(45deg, #0e6939, #0e6939);
            border-radius: 2px;
        }

        .decorative-lines::before {
            width: 30px;
            height: 3px;
            top: 10px;
            right: 0;
            opacity: 0.6;
        }

        .decorative-lines::after {
            width: 20px;
            height: 3px;
            top: 20px;
            right: 10px;
            opacity: 0.4;
        }

    </style>
</head>

<body>
    <?php if (isset($component)) { $__componentOriginal1599bb83f8a5081aa583bd9ac337e33d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1599bb83f8a5081aa583bd9ac337e33d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1599bb83f8a5081aa583bd9ac337e33d)): ?>
<?php $attributes = $__attributesOriginal1599bb83f8a5081aa583bd9ac337e33d; ?>
<?php unset($__attributesOriginal1599bb83f8a5081aa583bd9ac337e33d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1599bb83f8a5081aa583bd9ac337e33d)): ?>
<?php $component = $__componentOriginal1599bb83f8a5081aa583bd9ac337e33d; ?>
<?php unset($__componentOriginal1599bb83f8a5081aa583bd9ac337e33d); ?>
<?php endif; ?>
    <div id="in-cont">
        <div class="inn-title" style="padding-top: 150px">
            <h2><span><a href="<?php echo e(url('/')); ?>">الرئيسية</a> &raquo;</span>
                أعضاء مجلس الإدارة </h2>
        </div>
        <div style="padding-top: 50px; padding-bottom: 50px;">
            <h3 style="text-align: center; margin-bottom: 10px;">أعضاء مجلس الإدارة</h3>
            <div class="container-i1t">
                <div class="board-members-grid">
                    <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="board-member-card">
                        <img src="<?php echo e(asset('storage/' . $member->image)); ?>" alt="<?php echo e($member->name_ar); ?>">
                        <div>
                            <h2><?php echo e($member->name_ar); ?></h2>
                            <h3><?php echo e($member->position_ar); ?></h3>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div style="text-align: center; width: 100%;">
                        <p>لا يوجد أعضاء مجلس إدارة متاحون حالياً.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    </div>
    <?php if (isset($component)) { $__componentOriginal3fe645749ed3f4be8530f5256d446f0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fe645749ed3f4be8530f5256d446f0f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer-section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fe645749ed3f4be8530f5256d446f0f)): ?>
<?php $attributes = $__attributesOriginal3fe645749ed3f4be8530f5256d446f0f; ?>
<?php unset($__attributesOriginal3fe645749ed3f4be8530f5256d446f0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fe645749ed3f4be8530f5256d446f0f)): ?>
<?php $component = $__componentOriginal3fe645749ed3f4be8530f5256d446f0f; ?>
<?php unset($__componentOriginal3fe645749ed3f4be8530f5256d446f0f); ?>
<?php endif; ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.js"></script>
    <script src="<?php echo e(asset('assets/js/scriptU.js')); ?>"></script>
    </div>
</body>

</html>
<?php /**PATH F:\Retirees\resources\views/members/sidebar/members-list.blade.php ENDPATH**/ ?>