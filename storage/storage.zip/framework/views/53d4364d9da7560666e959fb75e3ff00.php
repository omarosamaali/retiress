<?php $__env->startSection('title', 'إدارة صفحة المجالس'); ?>
<?php $__env->startSection('page-title', 'إدارة صفحة المجالس'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .add-section {
        background: linear-gradient(135deg, #0e6939 0%, #0e6939 100%);
        color: white;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 30px;
    }

    .form-control,
    .form-select {
        border-radius: 8px;
        border: 1px solid #ddd;
        padding: 10px 15px;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: #0e6939;
        box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
    }

    .table-responsive {
        border-radius: 10px;
        overflow: hidden;
        margin-bottom: 30px;
        /* إضافة مسافة بين الجداول */
    }

    .action-buttons .btn {
        padding: 5px 10px;
        font-size: 12px;
        margin: 0 2px;
    }

    .about-img {
        width: 50px;
        height: auto;
        border-radius: 5px;
        box-shadow: 0 0 3px rgba(0, 0, 0, 0.2);
    }

</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-dark">كل المجالس</h6>
        <a href="<?php echo e(route('admin.council.create')); ?>" class="btn btn-success btn-sm">إضافة مجلس</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>تاريخ الإضافة</th>
                        <th>الإسم (عربي)</th>
                        <th>الوصف (عربي)</th>
                        <th>الصورة</th>
                        <th>الحالة</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>

                <?php if($councils): ?>
                <?php $__currentLoopData = $councils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $councils): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr>
                        <td><?php echo e($councils->id); ?></td>
                        <td><?php echo e(optional($councils->created_at)->format('d/m/Y') ?? 'N/A'); ?></td>
                        <td><?php echo e($councils->name_ar ?? 'لا يوجد عنوان'); ?></td>
                        <td><?php echo e(Str::limit($councils->description_ar ?? 'لا يوجد وصف','30')); ?></td>
                        <td>
                            <?php if($councils->image): ?>
                            <img src="<?php echo e(asset('storage/' . $councils->image)); ?>" alt="<?php echo e($councils->name_ar); ?>" class="about-img">
                            <?php else: ?>
                            لا توجد صورة
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge <?php echo e($councils->status_badge_class); ?>">
                                <?php echo e($councils->status_text); ?>

                            </span>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <a href="<?php echo e(route('admin.council.show', parameters: $councils->id)); ?>" class="btn btn-info btn-sm" title="عرض">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.council.edit', $councils->id)); ?>" class="btn btn-warning btn-sm" title="تعديل">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button class="btn btn-danger btn-sm" title="حذف" onclick="confirmDeleteModal('councils', <?php echo e($councils->id); ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="text-center py-4">
                    <i class="fas fa-info-circle text-muted" style="font-size: 3rem;"></i>
                    <p class="text-muted mt-2">لا يوجد لجان بعد. يرجى <a href="<?php echo e(route('admin.council.create')); ?>">الإضافة الآن</a></p>
                </div>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>




<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">تأكيد الحذف</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="deleteModalBody">
                هل أنت متأكد من حذف هذا العنصر؟
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                <form id="deleteForm" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">حذف</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // الدوال الخاصة بمعاينة الصور (إذا كنت تستخدم هذا الـ view للإضافة/التعديل، ولكن غالباً هذا الـ view للعرض فقط)
    // تم حذف هذا الجزء من السكربت لتجنب الازدواجية حيث أن هذا الـ view هو لعرض البيانات فقط.
    // إذا كنت تحتاج هذه الوظائف، يجب أن تكون في view الإضافة/التعديل.

    function confirmDeleteModal(type, id) {
        const deleteForm = document.getElementById('deleteForm');
        const deleteModalBody = document.getElementById('deleteModalBody');

        deleteForm.action = `/admin/council/${id}`;
        deleteModalBody.textContent = 'هل أنت متأكد من حذف محتوى صفحة "معلومات اللجنه ؟';

        const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
        deleteModal.show();
    }

</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Retirees\resources\views/admin/councils/index.blade.php ENDPATH**/ ?>