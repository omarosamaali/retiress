<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['magazines']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['magazines']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<style>
    @media (max-width: 500px) {
        .all-version {
            flex-direction: column;
        }
    }

</style>
<div class="container-9l2 container-s5k vc_-9ok" id="latest-section">
    <div class="row-gtg">
        <div class="container-i1t">
            <div class="row-1yt">
                <div class="container-sls col-rrx">
                    <div class="column-wcn">
                        <?php if($magazines): ?>
                        <div class="row-gtg vc_-ppz">
                            <div class="container-sls col-zbp">
                                <div class="column-wcn">
                                    <div>
                                        <div class="image-ksy content-zgb vc_-lpq">
                                            <figure class="vc_-ao4">
                                                <div class="wrapper-j81">
                                                    <img width="1275" height="743" src="<?php echo e(asset('storage/' . $magazines->main_image)); ?>" alt="<?php echo e($magazines->title_ar ?? 'أحدث إصدار'); ?>">
                                                </div>
                                            </figure>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="container-sls col-zbp">
                                <div class="column-wcn">
                                    <div>
                                        <div class="column-dx4 content-zgb header-f37">
                                            <div class="all-version" style="display: flex; align-items: center; justify-content: space-between;">
                                                <h1 id="style-Ksnz9" class="style-Ksnz9">
                                                    أخر إصدار مجلة نبض المتقاعد
                                                </h1>
                                                <a href="<?php echo e(route('magazines.all-magazines')); ?>">جميع الإصدارات</a>
                                            </div>
                                        </div>
                                        <div class="column-dx4 content-zgb">
                                            <div>
                                                <p dir="rtl" id="style-DRlzk" class="style-DRlzk">
                                                    <?php echo e($magazines->description_ar ?? 'لا يوجد وصف متاح.'); ?>

                                                </p>
                                            </div>
                                        </div>
                                        <div class="column-dx4 content-zgb">
                                            <p dir="rtl">تاريخ الإصدار: <?php echo e(\Carbon\Carbon::parse($magazines->created_at)->translatedFormat('d F Y')); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <p>لا توجد مجلات متاحة حالياً.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\Retirees\resources\views/components/latest-section.blade.php ENDPATH**/ ?>