<!DOCTYPE html>
<html>

<head>
    <link rel="icon" type="image/png" href="images/fav.png" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width; initial-scale=1;" />
    <title>جمعية الإمارات للمتقاعدين</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/other-devices.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleU.css')); ?>" />
    <script src="<?php echo e(asset('assets/js/modernizr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/amazingcarousel.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/amazingslider-1.css')); ?>">
    <script src="<?php echo e(asset('assets/js/initcarousel-1.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/amazingslider.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/amazingslider-2.css')); ?>">
    <script src="<?php echo e(asset('assets/js/initslider-2.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(path: 'assets/css/custom.css')); ?>">
    <style>
        .mobile-btn {
            display: none;
        }

        @media (max-width: 768px) {
            .mobile-btn {
                display: block;
            }
        }

        @media (max-width: 500px) {
            .dl-menuwrapper button {
                margin: 41px 78px 0 0px !important;
            }
        }

    </style>
</head>

<body ng-app="myApp">
    <div id="headerholdert">
        <img src="<?php echo e(Storage::url($banner->image)); ?>" alt="Header Background" style="width:100%; height:100%; object-fit:cover;">
    </div>
    <?php if (isset($component)) { $__componentOriginale5d2f2831f58fdbe96ad6d7cbd41a7dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5d2f2831f58fdbe96ad6d7cbd41a7dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5d2f2831f58fdbe96ad6d7cbd41a7dd)): ?>
<?php $attributes = $__attributesOriginale5d2f2831f58fdbe96ad6d7cbd41a7dd; ?>
<?php unset($__attributesOriginale5d2f2831f58fdbe96ad6d7cbd41a7dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5d2f2831f58fdbe96ad6d7cbd41a7dd)): ?>
<?php $component = $__componentOriginale5d2f2831f58fdbe96ad6d7cbd41a7dd; ?>
<?php unset($__componentOriginale5d2f2831f58fdbe96ad6d7cbd41a7dd); ?>
<?php endif; ?>

    <div id="latest-news" style="margin-top: 100px !important; display: flex; align-items: center; max-width: 1200px; width: 100%; margin: auto; justify-content: space-between;">
        <h3 style="text-align: center; font-size: 36px; width: 90%;">أحدث
            الأخبار</h3>
        <div class="c-morebtn" style="width: 10%;">
            <a href="<?php echo e(route("news.all-news")); ?>" class="main-btn" style="background-color: black;">المزيد
                من الأخبار</a></div>
    </div>
    <div style="max-width: 1200px; margin: auto;" class="list-l88 list-vja">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleNews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('/news/show/' . $singleNews->id)); ?>" class="list-2nx">
            <span class="image-dvm">
                <img width="688" height="1024" src="<?php echo e(asset('storage/' . $singleNews->main_image)); ?>" alt="<?php echo e($singleNews->title_ar); ?>">
            </span>
            <span class="list-o16 hqqhi">
                <span class="list-m72"><?php echo e(\Carbon\Carbon::parse($singleNews->created_at)->day); ?></span>
                <span><?php echo e(\Carbon\Carbon::parse($singleNews->created_at)->translatedFormat('F')); ?></span>
            </span>
            <span class="list-zkk">
                <span class="title-n5f qhngb">
                    <?php echo e($singleNews->title_ar); ?>

                </span>
                <span class="list-mzq">
                    <p><?php echo e(\Illuminate\Support\Str::limit($singleNews->description_ar, 200)); ?></p>
                </span>
            </span>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <section style="background: #016330; margin-top: 100px;">
        <div class="container-e3z">
            <div class="row-sy7">
                <div class="col-w5q">
                    <h1 class="font-weight-5zk text-jli" style="margin-top: 25px;">أحدث
                        الفعاليات</h1>
                    <p class="text-jli">برامج وخدمات اجتماعية وتربوية وثقافية منوعة لكافة
                        شرائح المجتمع مع التركيز على
                        فئة
                        الشباب بالتعاون والشراكة مع مختلف الجهات المعنية</p>
                </div>
                <div class="col-bpd">
                    <!-- Swiper -->
                    <div class="swiper eventsSwiper">
                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <a href="<?php echo e(url('/events/show/' . $event->id)); ?>" class="slide-content">
                                    <img src="<?php echo e(asset('storage/' . $event->main_image)); ?>" alt="<?php echo e($event->title_ar); ?>" class="slide-image">
                                    <div class="slide-title">
                                        <?php echo e($event->title_ar); ?>

                                    </div>
                                    <p style="padding-top: 20px; padding-right: 20px; margin-bottom: 15px;">التاريخ : <?php echo e(\Carbon\Carbon::parse($event->event_date)->translatedFormat('d F Y')); ?></p> 
                                </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- Add Pagination -->
                        <div class="swiper-pagination"></div>
                        <!-- Add Navigation -->
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                    <a href="<?php echo e(route('events.all-events')); ?>" class="btn-dwo block-qlo" style="display: block; text-align: center; margin-top: 30px;">
                        <i class="fas fa-eye"></i>
                        <span>شاهد المزيد</span>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <?php if (isset($component)) { $__componentOriginalc3de55e6de46fe9c28c984cea52d5339 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3de55e6de46fe9c28c984cea52d5339 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.events-section','data' => ['services' => $services]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('events-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['services' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($services)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3de55e6de46fe9c28c984cea52d5339)): ?>
<?php $attributes = $__attributesOriginalc3de55e6de46fe9c28c984cea52d5339; ?>
<?php unset($__attributesOriginalc3de55e6de46fe9c28c984cea52d5339); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3de55e6de46fe9c28c984cea52d5339)): ?>
<?php $component = $__componentOriginalc3de55e6de46fe9c28c984cea52d5339; ?>
<?php unset($__componentOriginalc3de55e6de46fe9c28c984cea52d5339); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal925d761c552e676b71625b7abcbe00d7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal925d761c552e676b71625b7abcbe00d7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.latest-section','data' => ['magazines' => $magazines]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('latest-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['magazines' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($magazines)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal925d761c552e676b71625b7abcbe00d7)): ?>
<?php $attributes = $__attributesOriginal925d761c552e676b71625b7abcbe00d7; ?>
<?php unset($__attributesOriginal925d761c552e676b71625b7abcbe00d7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal925d761c552e676b71625b7abcbe00d7)): ?>
<?php $component = $__componentOriginal925d761c552e676b71625b7abcbe00d7; ?>
<?php unset($__componentOriginal925d761c552e676b71625b7abcbe00d7); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal3fe645749ed3f4be8530f5256d446f0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fe645749ed3f4be8530f5256d446f0f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer-section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fe645749ed3f4be8530f5256d446f0f)): ?>
<?php $attributes = $__attributesOriginal3fe645749ed3f4be8530f5256d446f0f; ?>
<?php unset($__attributesOriginal3fe645749ed3f4be8530f5256d446f0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fe645749ed3f4be8530f5256d446f0f)): ?>
<?php $component = $__componentOriginal3fe645749ed3f4be8530f5256d446f0f; ?>
<?php unset($__componentOriginal3fe645749ed3f4be8530f5256d446f0f); ?>
<?php endif; ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.js"></script>
    <script src="<?php echo e(asset('assets/js/scriptU.js')); ?>"></script>
</body>

</html><?php /**PATH F:\Retirees\resources\views/dashboard.blade.php ENDPATH**/ ?>