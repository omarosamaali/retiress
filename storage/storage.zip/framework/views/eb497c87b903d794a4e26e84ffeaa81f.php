<!DOCTYPE html>
<html>

<head>
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/fav.png')); ?>" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width; initial-scale=1;" />
    <title>الرؤية والرسالة والأهداف</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/other-devices.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleU.css')); ?>" />
    <script src="<?php echo e(asset('assets/js/modernizr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/amazingcarousel.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/amazingslider-1.css')); ?>">
    <script src="<?php echo e(asset('assets/js/initcarousel-1.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/amazingslider.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/amazingslider-2.css')); ?>">
    <script src="<?php echo e(asset('assets/js/initslider-2.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(path: 'assets/css/custom.css')); ?>">

    <style>
        .container-info {
            margin-right: 5px;
            display: flex;
            align-items: baseline;
            justify-content: space-between;
            gap: 5px;
        }

        .box {
            height: 7px;
            width: 7px;
            background-color: white;
            border-radius: 0px;
        }

        .-mt-9 {
            margin-top: -9px;
        }
    </style>
</head>

<body>
    <?php if (isset($component)) { $__componentOriginal1599bb83f8a5081aa583bd9ac337e33d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1599bb83f8a5081aa583bd9ac337e33d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1599bb83f8a5081aa583bd9ac337e33d)): ?>
<?php $attributes = $__attributesOriginal1599bb83f8a5081aa583bd9ac337e33d; ?>
<?php unset($__attributesOriginal1599bb83f8a5081aa583bd9ac337e33d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1599bb83f8a5081aa583bd9ac337e33d)): ?>
<?php $component = $__componentOriginal1599bb83f8a5081aa583bd9ac337e33d; ?>
<?php unset($__componentOriginal1599bb83f8a5081aa583bd9ac337e33d); ?>
<?php endif; ?>
    <div id="in-cont">
        <div class="inn-title" style="padding-top: 150px">
            <h2><span><a href="<?php echo e(url('/')); ?>">الرئيسية</a> &raquo;</span>
                الرؤية والرسالة والأهداف </h2>
        </div>
        <div id="iconsblocks">
            <ul id="alliconsandtext">
                <li class="icon-right">
                    <span style="margin-top:-5px;">رؤيتنا</span>
                    <div class="icon-holder">
                        <?php if($vision): ?>
                        <img src="<?php echo e(asset('storage/' . $vision->main_image)); ?>" alt="<?php echo e($vision->title_ar); ?>">
                        <?php endif; ?>
                    </div>
                </li>

                <li class="text-left">
                    <div class="text-holder">
                        <?php if($vision): ?>
                        <h3 class="main-titles"><?php echo e($vision->title_ar); ?></h3>
                        <p class="info vision container-info">
                            <span class="box"></span>
                            <span class="info vision"><?php echo e($vision->description_ar); ?></span>
                        </p>
                        <?php endif; ?>
                    </div>
                </li>

                <li class="-mt-9 icon-left">
                    <span>أهدافنا</span>
                    <div class="icon-holder">
                        <?php if($company_message): ?>
                        <img src="<?php echo e(asset('storage/' . $company_message->main_image)); ?>" class="goalsimg">
                        <?php endif; ?>
                    </div>
                </li>

                <li class="-mt-9 text-right">
                    <div class="text-holder">
                        <?php if($company_message): ?>
                        <h3 class="main-titles"><?php echo e($company_message->title_ar); ?></h3>
                        <ul class="info goals">
                            <li><?php echo e($company_message->description_ar); ?></li>
                        </ul>
                        <?php endif; ?>
                    </div>
                </li>

                
            </ul>
        </div>

    </div>

    </div>
    <?php if (isset($component)) { $__componentOriginal3fe645749ed3f4be8530f5256d446f0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fe645749ed3f4be8530f5256d446f0f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer-section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fe645749ed3f4be8530f5256d446f0f)): ?>
<?php $attributes = $__attributesOriginal3fe645749ed3f4be8530f5256d446f0f; ?>
<?php unset($__attributesOriginal3fe645749ed3f4be8530f5256d446f0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fe645749ed3f4be8530f5256d446f0f)): ?>
<?php $component = $__componentOriginal3fe645749ed3f4be8530f5256d446f0f; ?>
<?php unset($__componentOriginal3fe645749ed3f4be8530f5256d446f0f); ?>
<?php endif; ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.7/swiper-bundle.min.js"></script>
    <script src="<?php echo e(asset('assets/js/scriptU.js')); ?>"></script>
</body>

</html>
<?php /**PATH F:\Retirees\resources\views/members/sidebar/vision.blade.php ENDPATH**/ ?>